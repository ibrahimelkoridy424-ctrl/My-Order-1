-- Professional MySQL Database Schema for Restaurant Ordering System
-- This schema includes two tables: orders and order_items
-- Designed for advanced analytics and invoicing with proper data integrity

-- Create database if it doesn't exist
CREATE DATABASE IF NOT EXISTS restaurant_orders;
USE restaurant_orders;

-- Orders table: Stores general order information
CREATE TABLE orders (
    order_id INT AUTO_INCREMENT PRIMARY KEY,
    customer_name VARCHAR(255) NOT NULL,
    phone VARCHAR(20),
    address TEXT,
    total_price DECIMAL(10, 2) NOT NULL DEFAULT 0.00,
    order_status ENUM('pending', 'confirmed', 'preparing', 'ready', 'delivered', 'cancelled') DEFAULT 'pending',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    
    -- Indexes for performance
    INDEX idx_customer_name (customer_name),
    INDEX idx_order_status (order_status),
    INDEX idx_created_at (created_at)
);

-- Order items table: Stores specific items for each order
CREATE TABLE order_items (
    item_id INT AUTO_INCREMENT PRIMARY KEY,
    order_id INT NOT NULL,
    item_name VARCHAR(255) NOT NULL,
    quantity INT NOT NULL CHECK (quantity > 0),
    unit_price DECIMAL(10, 2) NOT NULL CHECK (unit_price >= 0),
    subtotal DECIMAL(10, 2) NOT NULL CHECK (subtotal >= 0),
    
    -- Foreign key constraint with cascade delete
    FOREIGN KEY (order_id) REFERENCES orders(order_id) ON DELETE CASCADE,
    
    -- Indexes for performance
    INDEX idx_order_id (order_id),
    INDEX idx_item_name (item_name)
);

-- Optional: Add a trigger to automatically calculate subtotal
DELIMITER //
CREATE TRIGGER calculate_subtotal BEFORE INSERT ON order_items
FOR EACH ROW
BEGIN
    SET NEW.subtotal = NEW.quantity * NEW.unit_price;
END;
//
DELIMITER ;

-- Optional: Add a trigger to update subtotal on update
DELIMITER //
CREATE TRIGGER update_subtotal BEFORE UPDATE ON order_items
FOR EACH ROW
BEGIN
    SET NEW.subtotal = NEW.quantity * NEW.unit_price;
END;
//
DELIMITER ;

-- Optional: Add a trigger to update total_price in orders table
DELIMITER //
CREATE TRIGGER update_order_total AFTER INSERT ON order_items
FOR EACH ROW
BEGIN
    UPDATE orders 
    SET total_price = (SELECT SUM(subtotal) FROM order_items WHERE order_id = NEW.order_id)
    WHERE order_id = NEW.order_id;
END;
//
DELIMITER ;

DELIMITER //
CREATE TRIGGER update_order_total_on_update AFTER UPDATE ON order_items
FOR EACH ROW
BEGIN
    UPDATE orders 
    SET total_price = (SELECT SUM(subtotal) FROM order_items WHERE order_id = NEW.order_id)
    WHERE order_id = NEW.order_id;
END;
//
DELIMITER ;

DELIMITER //
CREATE TRIGGER update_order_total_on_delete AFTER DELETE ON order_items
FOR EACH ROW
BEGIN
    UPDATE orders 
    SET total_price = (SELECT COALESCE(SUM(subtotal), 0) FROM order_items WHERE order_id = OLD.order_id)
    WHERE order_id = OLD.order_id;
END;
//
DELIMITER ;