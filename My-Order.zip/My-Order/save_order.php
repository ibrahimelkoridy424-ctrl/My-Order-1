<?php
declare(strict_types=1);

header('Content-Type: application/json; charset=utf-8');

$dbHost = 'localhost';
$dbName = 'restaurant_orders'; // Change this to your phpMyAdmin database name if different
$dsn = "mysql:host={$dbHost};dbname={$dbName};charset=utf8mb4";
$dbUser = 'root';
$dbPass = '';
$options = [
    PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
    PDO::ATTR_EMULATE_PREPARES => false,
];

function respond(int $statusCode, array $payload): void
{
    http_response_code($statusCode);
    echo json_encode($payload, JSON_UNESCAPED_UNICODE);
    exit;
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    respond(405, [
        'success' => false,
        'error' => 'Method not allowed. Use POST.',
    ]);
}

$contentType = $_SERVER['CONTENT_TYPE'] ?? '';
if (stripos($contentType, 'application/json') === false) {
    respond(415, [
        'success' => false,
        'error' => 'Content-Type must be application/json.',
    ]);
}

$rawBody = file_get_contents('php://input');
$data = json_decode($rawBody, true);
if (!is_array($data) || json_last_error() !== JSON_ERROR_NONE) {
    respond(400, [
        'success' => false,
        'error' => 'Invalid JSON payload.',
    ]);
}

$customerName = trim((string) ($data['customer_name'] ?? ''));
$phone = trim((string) ($data['phone'] ?? ''));
$address = trim((string) ($data['address'] ?? ''));
$items = $data['cart_items'] ?? [];

if ($customerName === '') {
    respond(422, [
        'success' => false,
        'error' => 'Customer name is required.',
    ]);
}

if (!is_array($items) || count($items) === 0) {
    respond(422, [
        'success' => false,
        'error' => 'Order items are required.',
    ]);
}

try {
    $pdo = new PDO($dsn, $dbUser, $dbPass, $options);
    $pdo->beginTransaction();

    $orderStmt = $pdo->prepare(
        'INSERT INTO orders (customer_name, phone, address, total_price) VALUES (:customer_name, :phone, :address, :total_price)'
    );

    $computedTotal = 0.0;
    $itemRows = [];

    foreach ($items as $item) {
        $itemName = trim((string) ($item['itemName'] ?? $item['item_name'] ?? $item['name'] ?? $item['title'] ?? null));
        $quantity = isset($item['quantity']) ? (int) $item['quantity'] : (isset($item['qty']) ? (int) $item['qty'] : 0);
        $unitPrice = isset($item['unit_price']) ? (float) $item['unit_price'] : (isset($item['unitPrice']) ? (float) $item['unitPrice'] : (isset($item['price']) ? (float) $item['price'] : 0.0));

        if ($itemName === '') {
            // قد يكون لم يتم تحديد اسم العنصر في بعض الإصدارات القديمة.
            $itemName = 'غير معروف';
        }
        if ($quantity <= 0) {
            $quantity = 1;
        }
        if ($unitPrice < 0) {
            $unitPrice = 0;
        }

        $subtotal = round($quantity * $unitPrice, 2);
        $computedTotal += $subtotal;
        $itemRows[] = [
            'item_name' => $itemName,
            'quantity' => $quantity,
            'unit_price' => $unitPrice,
            'subtotal' => $subtotal,
        ];
    }

    $orderStmt->execute([
        ':customer_name' => $customerName,
        ':phone' => $phone,
        ':address' => $address,
        ':total_price' => $computedTotal,
    ]);

    $orderId = (int) $pdo->lastInsertId();
    if ($orderId <= 0) {
        throw new RuntimeException('Failed to create order.');
    }

    $itemStmt = $pdo->prepare(
        'INSERT INTO order_items (order_id, item_name, quantity, unit_price, subtotal) VALUES (:order_id, :item_name, :quantity, :unit_price, :subtotal)'
    );

    foreach ($itemRows as $row) {
        $itemStmt->execute([
            ':order_id' => $orderId,
            ':item_name' => $row['item_name'],
            ':quantity' => $row['quantity'],
            ':unit_price' => $row['unit_price'],
            ':subtotal' => $row['subtotal'],
        ]);
    }

    $pdo->commit();

    respond(201, [
        'success' => true,
        'message' => 'Order saved successfully.',
        'order_id' => $orderId,
        'total_price' => number_format($computedTotal, 2, '.', ''),
    ]);
} catch (Throwable $exception) {
    if (isset($pdo) && $pdo->inTransaction()) {
        $pdo->rollBack();
    }

    $errorMessage = $exception->getMessage();
    respond(500, [
        'success' => false,
        'error' => 'Failed to save order: ' . $errorMessage,
    ]);
}
