<?php
declare(strict_types=1);

header('Content-Type: application/json; charset=utf-8');

$dbHost = 'localhost';
$dbName = 'restaurant_orders';
$dbUser = 'root';
$dbPass = '';
$dsn = "mysql:host={$dbHost};dbname={$dbName};charset=utf8mb4";
$options = [
    PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
    PDO::ATTR_EMULATE_PREPARES => false,
];

function respond(int $statusCode, array $payload): void
{
    http_response_code($statusCode);
    echo json_encode($payload, JSON_UNESCAPED_UNICODE);
    exit;
}

try {
    $pdo = new PDO($dsn, $dbUser, $dbPass, $options);

    // Total orders count
    $totalOrdersStmt = $pdo->prepare('SELECT COUNT(*) AS total_orders FROM orders');
    $totalOrdersStmt->execute();
    $totalOrders = (int) $totalOrdersStmt->fetch()['total_orders'];

    // Total revenue (sum of prices)
    $totalRevenueStmt = $pdo->prepare('SELECT COALESCE(SUM(total_price), 0) AS total_revenue FROM orders');
    $totalRevenueStmt->execute();
    $totalRevenue = (float) $totalRevenueStmt->fetch()['total_revenue'];

    // Latest 10 orders
    $latestOrdersStmt = $pdo->prepare('SELECT order_id, customer_name, phone, address, total_price, order_status, created_at AS order_date FROM orders ORDER BY created_at DESC LIMIT 10');
    $latestOrdersStmt->execute();
    $latestOrders = $latestOrdersStmt->fetchAll();

    // Daily revenue for the last 7 days
    $dailyRevenueStmt = $pdo->prepare('
        SELECT DATE(created_at) as date, COALESCE(SUM(total_price), 0) as revenue
        FROM orders
        WHERE created_at >= DATE_SUB(CURDATE(), INTERVAL 6 DAY)
        GROUP BY DATE(created_at)
        ORDER BY DATE(created_at) ASC
    ');
    $dailyRevenueStmt->execute();
    $dailyRevenue = $dailyRevenueStmt->fetchAll();

    // Category sales (assuming we have order_items table with item categories)
    // For now, we'll return empty categories since we don't have the full schema
    $categorySales = [
        'food' => 0,
        'drinks' => 0,
        'sweets' => 0
    ];

    // Try to get category data if order_items table exists
    try {
        $categoryStmt = $pdo->prepare('
            SELECT
                CASE
                    WHEN LOWER(item_name) LIKE \'%قهوة%\' OR LOWER(item_name) LIKE \'%شاي%\' OR LOWER(item_name) LIKE \'%عصير%\' OR LOWER(item_name) LIKE \'%ماء%\' THEN \'drinks\'
                    WHEN LOWER(item_name) LIKE \'%حلوى%\' OR LOWER(item_name) LIKE \'%كيك%\' OR LOWER(item_name) LIKE \'%بسكويت%\' THEN \'sweets\'
                    ELSE \'food\'
                END as category,
                SUM(quantity * unit_price) as revenue
            FROM order_items
            GROUP BY category
        ');
        $categoryStmt->execute();
        $categoryResults = $categoryStmt->fetchAll();

        foreach ($categoryResults as $row) {
            $categorySales[$row['category']] = (float) $row['revenue'];
        }
    } catch (Exception $e) {
        // Table might not exist, continue with empty categories
    }

    // أكثر منتج مبيعاً
    $topProductStmt = $pdo->prepare('SELECT item_name, SUM(quantity) AS total_qty FROM order_items GROUP BY item_name ORDER BY total_qty DESC LIMIT 1');
    $topProductStmt->execute();
    $topProductRow = $topProductStmt->fetch();
    $topProduct = $topProductRow && !empty(trim((string)($topProductRow['item_name'] ?? ''))) ? $topProductRow['item_name'] : 'No Data';

    // Peak ordering time
    $peakHourStmt = $pdo->prepare('SELECT HOUR(created_at) AS peak_hour, COUNT(*) AS cnt FROM orders GROUP BY peak_hour ORDER BY cnt DESC LIMIT 1');
    $peakHourStmt->execute();
    $peakHourRow = $peakHourStmt->fetch();
    if ($peakHourRow && isset($peakHourRow['peak_hour']) && $peakHourRow['peak_hour'] !== null) {
        $hourInt = (int)$peakHourRow['peak_hour'];
        $peakHour = str_pad((string)$hourInt, 2, '0', STR_PAD_LEFT) . ':00';
    } else {
        $peakHour = 'No Data';
    }

    // Check for missing/unavailable items
    $missingItemsStmt = $pdo->prepare('
        SELECT
            item_name,
            MAX(created_at) as last_ordered,
            DATEDIFF(CURDATE(), MAX(created_at)) as days_since_last_order
        FROM order_items oi
        JOIN orders o ON oi.order_id = o.order_id
        GROUP BY item_name
        HAVING days_since_last_order > 7
        ORDER BY days_since_last_order DESC
        LIMIT 10
    ');
    $missingItemsStmt->execute();
    $missingItems = $missingItemsStmt->fetchAll();

    respond(200, [
        'success' => true,
        'total_orders' => $totalOrders,
        'total_revenue' => $totalRevenue,
        'top_product' => $topProduct,
        'peak_hour' => $peakHour,
        'latest_orders' => $latestOrders,
        'daily_revenue' => $dailyRevenue,
        'category_sales' => $categorySales,
        'missing_items' => $missingItems,
        'missing_items_count' => count($missingItems),
    ]);

} catch (Throwable $e) {
    respond(500, [
        'success' => false,
        'error' => 'خطأ في الخادم: ' . $e->getMessage(),
    ]);
}
?>